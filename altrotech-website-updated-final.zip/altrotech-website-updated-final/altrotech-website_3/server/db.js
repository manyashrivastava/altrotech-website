const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_DATABASE || 'altrotech_db',
});

// Test connection and create tables
async function initializeDatabase() {
  try {
    // Create database if it doesn't exist
    const adminPool = new Pool({
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASSWORD || 'postgres',
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 5432,
      database: 'postgres',
    });

    const dbName = process.env.DB_DATABASE || 'altrotech_db';
    const checkDb = await adminPool.query(
      `SELECT 1 FROM pg_database WHERE datname = '${dbName}'`
    );

    if (checkDb.rows.length === 0) {
      await adminPool.query(`CREATE DATABASE "${dbName}"`);
      console.log(`✅ Database "${dbName}" created successfully`);
    }
    await adminPool.end();

    // Create tables
    const client = await pool.connect();

    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        phone VARCHAR(50),
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        image VARCHAR(255),
        category VARCHAR(100),
        stock INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS cart (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
        quantity INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, product_id)
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        total_amount DECIMAL(10, 2) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        payment_method VARCHAR(100),
        transaction_id VARCHAR(255),
        shipping_address TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS order_items (
        id SERIAL PRIMARY KEY,
        order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
        product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
        product_name VARCHAR(255),
        quantity INTEGER NOT NULL,
        price DECIMAL(10, 2) NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS payments (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
        amount DECIMAL(10, 2) NOT NULL,
        method VARCHAR(100) NOT NULL,
        status VARCHAR(50) DEFAULT 'completed',
        transaction_id VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Seed products if empty
    const productCount = await client.query('SELECT COUNT(*) FROM products');
    if (parseInt(productCount.rows[0].count) === 0) {
      const seedProducts = [
        ['DC/DC Isolated Converter', 'High-performance isolated converters with wide input range and multiple output options.', 45.00, '🔌', 'dc-dc', 50],
        ['Non-Isolated DC/DC Converter', 'Compact and efficient non-isolated solutions for cost-sensitive applications.', 25.00, '⚡', 'dc-dc', 100],
        ['AC/DC Power Supply', 'Robust AC/DC power supplies with universal input and integrated protection features.', 65.00, '🔋', 'ac-dc', 30],
        ['I/O Module', 'Advanced I/O modules for signal conditioning and industrial interfacing applications.', 35.00, '📊', 'io', 75],
        ['Signal Conditioning Module', 'Precision signal conditioning for accurate data acquisition and processing.', 40.00, '🎛️', 'signal', 60],
        ['Industrial Power Solution', 'Comprehensive power solutions designed for demanding industrial environments.', 95.00, '🛡️', 'industrial', 25],
      ];

      for (const product of seedProducts) {
        await client.query(
          'INSERT INTO products (name, description, price, image, category, stock) VALUES ($1, $2, $3, $4, $5, $6)',
          product
        );
      }
      console.log('✅ Products seeded successfully');
    }

    client.release();
    console.log('✅ Database tables created successfully');
    return pool;
  } catch (error) {
    console.error('❌ Database initialization error:', error.message);
    throw error;
  }
}

module.exports = { pool, initializeDatabase };

