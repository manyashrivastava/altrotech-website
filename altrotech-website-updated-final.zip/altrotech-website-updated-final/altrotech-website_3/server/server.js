const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool, initializeDatabase } = require('./db');
const { authenticateToken, generateToken } = require('./auth');
require('dotenv').config();

const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// Serve static frontend files
app.use(express.static(path.join(__dirname, '..')));
app.use('/altrotech', express.static(path.join(__dirname, '../altrotech')));


// ==================== HEALTH CHECK ====================
app.get('/api/health', async (req, res) => {
  try {
    const result = await pool.query('SELECT NOW()');
    res.json({ status: 'ok', time: result.rows[0].now });
  } catch (error) {
    res.status(500).json({ error: 'Database connection failed' });
  }
});

// ==================== AUTH ROUTES ====================

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required' });
    }

    // Check if user exists
    const existingUser = await pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );

    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: 'User already exists with this email' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user
    const result = await pool.query(
      'INSERT INTO users (name, email, phone, password) VALUES ($1, $2, $3, $4) RETURNING id, name, email, phone, created_at',
      [name, email, phone || null, hashedPassword]
    );

    const user = result.rows[0];
    const token = generateToken(user);

    res.status(201).json({
      message: 'User created successfully',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        joinDate: user.created_at
      },
      token
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find user
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const user = result.rows[0];

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = generateToken(user);

    res.json({
      message: 'Login successful',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        joinDate: user.created_at
      },
      token
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get current user profile
app.get('/api/auth/profile', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, email, phone, created_at FROM users WHERE id = $1',
      [req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = result.rows[0];
    res.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        joinDate: user.created_at
      }
    });
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ==================== PRODUCTS ROUTES ====================

// Get all products
app.get('/api/products', async (req, res) => {
  try {
    const { category } = req.query;
    let query = 'SELECT * FROM products';
    let params = [];

    if (category) {
      query += ' WHERE category = $1';
      params.push(category);
    }

    query += ' ORDER BY id ASC';
    const result = await pool.query(query, params);

    res.json({ products: result.rows });
  } catch (error) {
    console.error('Products fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single product
app.get('/api/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM products WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json({ product: result.rows[0] });
  } catch (error) {
    console.error('Product fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ==================== CART ROUTES ====================

// Get user's cart
app.get('/api/cart', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT c.id, c.quantity, p.id as product_id, p.name, p.price, p.image, p.description
       FROM cart c
       JOIN products p ON c.product_id = p.id
       WHERE c.user_id = $1
       ORDER BY c.created_at DESC`,
      [req.user.id]
    );

    const total = result.rows.reduce((sum, item) => sum + (parseFloat(item.price) * item.quantity), 0);

    res.json({
      items: result.rows,
      total: parseFloat(total.toFixed(2)),
      count: result.rows.length
    });
  } catch (error) {
    console.error('Cart fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add to cart
app.post('/api/cart/add', authenticateToken, async (req, res) => {
  try {
    const { product_id, quantity = 1 } = req.body;

    if (!product_id) {
      return res.status(400).json({ error: 'Product ID is required' });
    }

    // Check if product exists
    const productResult = await pool.query('SELECT * FROM products WHERE id = $1', [product_id]);
    if (productResult.rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    // Check if already in cart
    const existingItem = await pool.query(
      'SELECT * FROM cart WHERE user_id = $1 AND product_id = $2',
      [req.user.id, product_id]
    );

    if (existingItem.rows.length > 0) {
      // Update quantity
      await pool.query(
        'UPDATE cart SET quantity = quantity + $1 WHERE user_id = $2 AND product_id = $3',
        [quantity, req.user.id, product_id]
      );
    } else {
      // Add new item
      await pool.query(
        'INSERT INTO cart (user_id, product_id, quantity) VALUES ($1, $2, $3)',
        [req.user.id, product_id, quantity]
      );
    }

    // Get updated cart
    const updatedCart = await pool.query(
      `SELECT c.id, c.quantity, p.id as product_id, p.name, p.price, p.image
       FROM cart c
       JOIN products p ON c.product_id = p.id
       WHERE c.user_id = $1
       ORDER BY c.created_at DESC`,
      [req.user.id]
    );

    const product = productResult.rows[0];
    res.json({
      message: `${product.name} added to cart`,
      items: updatedCart.rows,
      count: updatedCart.rows.length
    });
  } catch (error) {
    console.error('Cart add error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Remove from cart
app.delete('/api/cart/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      'DELETE FROM cart WHERE id = $1 AND user_id = $2 RETURNING *',
      [id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Cart item not found' });
    }

    // Get updated cart
    const updatedCart = await pool.query(
      `SELECT c.id, c.quantity, p.id as product_id, p.name, p.price, p.image
       FROM cart c
       JOIN products p ON c.product_id = p.id
       WHERE c.user_id = $1
       ORDER BY c.created_at DESC`,
      [req.user.id]
    );

    res.json({
      message: 'Item removed from cart',
      items: updatedCart.rows,
      count: updatedCart.rows.length
    });
  } catch (error) {
    console.error('Cart remove error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Clear cart
app.delete('/api/cart', authenticateToken, async (req, res) => {
  try {
    await pool.query('DELETE FROM cart WHERE user_id = $1', [req.user.id]);
    res.json({ message: 'Cart cleared', items: [], count: 0 });
  } catch (error) {
    console.error('Cart clear error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ==================== ORDERS ROUTES ====================

// Create order (checkout)
app.post('/api/orders', authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    const { payment_method, shipping_address } = req.body;
    const userId = req.user.id;

    await client.query('BEGIN');

    // Get cart items
    const cartResult = await client.query(
      `SELECT c.id, c.quantity, c.product_id, p.name, p.price, p.stock
       FROM cart c
       JOIN products p ON c.product_id = p.id
       WHERE c.user_id = $1`,
      [userId]
    );

    if (cartResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Cart is empty' });
    }

    // Calculate total
    const totalAmount = cartResult.rows.reduce(
      (sum, item) => sum + (parseFloat(item.price) * item.quantity),
      0
    );

    // Generate transaction ID
    const transactionId = 'TXN' + Date.now() + Math.random().toString(36).substr(2, 5).toUpperCase();

    // Create order
    const orderResult = await client.query(
      `INSERT INTO orders (user_id, total_amount, status, payment_method, transaction_id, shipping_address)
       VALUES ($1, $2, 'completed', $3, $4, $5)
       RETURNING *`,
      [userId, totalAmount, payment_method || 'card', transactionId, shipping_address || null]
    );

    const order = orderResult.rows[0];

    // Create order items
    for (const item of cartResult.rows) {
      await client.query(
        `INSERT INTO order_items (order_id, product_id, product_name, quantity, price)
         VALUES ($1, $2, $3, $4, $5)`,
        [order.id, item.product_id, item.name, item.quantity, item.price]
      );

      // Update stock
      await client.query(
        'UPDATE products SET stock = stock - $1 WHERE id = $2 AND stock >= $1',
        [item.quantity, item.product_id]
      );
    }

    // Record payment
    await client.query(
      `INSERT INTO payments (user_id, order_id, amount, method, status, transaction_id)
       VALUES ($1, $2, $3, $4, 'completed', $5)`,
      [userId, order.id, totalAmount, payment_method || 'card', transactionId]
    );

    // Clear cart
    await client.query('DELETE FROM cart WHERE user_id = $1', [userId]);

    await client.query('COMMIT');

    res.status(201).json({
      message: 'Order placed successfully',
      order: {
        id: order.id,
        totalAmount: parseFloat(order.total_amount),
        status: order.status,
        transactionId: order.transaction_id,
        createdAt: order.created_at
      }
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Order creation error:', error);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    client.release();
  }
});

// Get user's orders
app.get('/api/orders', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT o.*, 
        (SELECT json_agg(json_build_object(
          'id', oi.id,
          'productName', oi.product_name,
          'quantity', oi.quantity,
          'price', oi.price
        )) FROM order_items oi WHERE oi.order_id = o.id) as items
       FROM orders o
       WHERE o.user_id = $1
       ORDER BY o.created_at DESC`,
      [req.user.id]
    );

    res.json({ orders: result.rows });
  } catch (error) {
    console.error('Orders fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ==================== PAYMENTS ROUTES ====================

// Process payment
app.post('/api/payments', authenticateToken, async (req, res) => {
  try {
    const { amount, method, order_id } = req.body;

    if (!amount || !method) {
      return res.status(400).json({ error: 'Amount and payment method are required' });
    }

    // Generate transaction ID
    const transactionId = 'PAY' + Date.now() + Math.random().toString(36).substr(2, 6).toUpperCase();

    // Record payment
    const result = await pool.query(
      `INSERT INTO payments (user_id, order_id, amount, method, status, transaction_id)
       VALUES ($1, $2, $3, $4, 'completed', $5)
       RETURNING *`,
      [req.user.id, order_id || null, amount, method, transactionId]
    );

    res.status(201).json({
      message: 'Payment processed successfully',
      payment: {
        id: result.rows[0].id,
        transactionId: result.rows[0].transaction_id,
        amount: parseFloat(result.rows[0].amount),
        method: result.rows[0].method,
        status: result.rows[0].status
      }
    });
  } catch (error) {
    console.error('Payment processing error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get payment history
app.get('/api/payments', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM payments WHERE user_id = $1 ORDER BY created_at DESC`,
      [req.user.id]
    );
    res.json({ payments: result.rows });
  } catch (error) {
    console.error('Payments fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ==================== CONTACT ROUTE ====================
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, company, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
      return res.status(400).json({ error: 'Name, email, subject and message are required' });
    }

    // In production, send email here
    console.log('Contact form submission:', { name, email, phone, company, subject, message });

    res.json({
      message: 'Thank you! Your message has been received. We will get back to you soon.'
    });
  } catch (error) {
    console.error('Contact error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ==================== STATS ROUTE ====================
app.get('/api/stats', async (req, res) => {
  try {
    const clientsResult = await pool.query('SELECT COUNT(DISTINCT id) as count FROM users');
    const productsResult = await pool.query('SELECT COUNT(*) as count FROM products');
    const ordersResult = await pool.query('SELECT COUNT(*) as count FROM orders');

    // Simulated stats since we're building data
    res.json({
      clients: Math.max(parseInt(clientsResult.rows[0].count) * 10, 500),
      projects: Math.max(parseInt(ordersResult.rows[0].count) * 2, 1000),
      experience: 15,
      satisfaction: 99.8
    });
  } catch (error) {
    // Return default stats on error
    res.json({
      clients: 500,
      projects: 1000,
      experience: 15,
      satisfaction: 99.8
    });
  }
});

// ==================== INITIALIZE & START ====================
async function startServer() {
  try {
    await initializeDatabase();
    console.log('✅ Database connected & initialized');
  } catch (error) {
    console.warn('⚠️ Database connection warning:', error.message);
    console.warn('⚠️ Running in standalone mode with LocalStorage fallback');
  }

  app.listen(PORT, () => {
    console.log(`✅ AltroTech Website running on http://localhost:${PORT}`);
    console.log(`✅ API available at http://localhost:${PORT}/api`);
  });
}

startServer();

module.exports = app;

